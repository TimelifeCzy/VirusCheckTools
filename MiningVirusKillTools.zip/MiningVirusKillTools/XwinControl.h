﻿#pragma once

#include "stdafx.h"
#include <vector>
#include "HistogramCtrl.h"

using namespace std;

// XwinControl 对话框

class XwinControl : public CDialogEx
{
	DECLARE_DYNAMIC(XwinControl)

public:
	XwinControl(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~XwinControl();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
	CListCtrl m_List1;
	virtual BOOL OnInitDialog();
	CStatic m_Pictrue;
	afx_msg void OnBnClickedButton3();

	// 查杀核心进程
	BOOL GetProcessVirus();
	BOOL FindVirusProcess();



private:
	TCHAR pszFileName[MAX_PATH] = { };
	TCHAR bufs[MAX_PATH] = {};
	// 全局list id
	DWORD g_index = 0;
	DWORD g_orderid = 0;

	// 提权
	void GetSystempermissions();

	// 获取进程CPU占用率
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	CEdit m_cpuinfo;

	// CPU状态动态监控
	CString m_Cpusyl;
	double GetCpuInfo();

	afx_msg void OnBnClickedButton4();

	afx_msg void OnBnClickedButton5();

public:
	static vector<VIRUSDATA> g_BlackList;
	//创建瀑布图对象
	CHistogramCtrl m_CpuGroup;
	// 监控flag
	BOOL g_MonitorCpuflag = 0;
	HANDLE hMonitorCpu = NULL;
	CStatic m_MonitorFlagText;
//	CButton m_ScanProces;
	CStatic m_ScanProcess;
};
