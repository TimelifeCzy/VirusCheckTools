//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� MiningVirusKillTools.rc ʹ��
//
#define IDD_DIALOG1                     101
#define IDI_ICON1                       103
#define IDB_BITMAP1                     104
#define IDD_DIALOG2                     105
#define IDD_DIALOG3                     107
#define IDC_LIST1                       1001
#define IDC_BUTTON1                     1002
#define IDC_BUTTON2                     1003
#define IDC_BUTTON3                     1004
#define IDC_STATIC1                     1005
#define IDC_BUTTON4                     1006
#define IDC_BUTTON5                     1007
#define IDC_EDIT2                       1011
#define IDC_EDIT1                       1012
#define IDC_STATIC_CPU                  1014
#define IDC_STATIC_MonText              1015
#define IDC_STATIC_CHECKPROCESS         1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
