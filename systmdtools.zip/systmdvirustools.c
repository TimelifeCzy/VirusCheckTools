#include <unistd.h>
#include <stdio.h>
#include<fcntl.h>
#include<assert.h>
// 1. check rc.d
// 2. check crontab
// 3. check Virusfile

//  固定文件检查/删除
//  计划任务检查/删除
//  添加的lnk检查删除 

void CheckVirusFile()
{
	int flag = 0;
	if (access("/usr/bin/sysetmde808a755", F_OK) == 0)
    {
		flag = 1;
        printf("[+] 发现Systmd病毒-sysetmde808a755\n");
		remove("/usr/bin/sysetmde808a755");
		printf("[-] 已清除威胁\n");
    }
	if(access("/bin/sysetmde808a755",F_OK)==0)
	{
		flag = 1;
		printf("[+] 发现Systmd病毒-sysetmde808a755\n");
		remove("/bin/sysetmde808a755")
		printf("[-] 已清除威胁\n");
	}
	if (access("/usr/bin/sysetmd46207ba9", F_OK) == 0)
    {
		flag = 1;
        printf("[+] 发现Systmd病毒-sysetmd46207ba9\n");
		remove("/usr/bin/sysetmd46207ba9");
		printf("[-] 已清除威胁\n");
    }
	if(access("/bin/sysetmd46207ba9",F_OK)==0)
	{
		flag = 1;
		printf("[+] 发现Systmd病毒-sysetmd46207ba9\n");
		remove("/bin/sysetmd46207ba9");
		printf("[-] 已清除威胁\n");
	}
	if (access("/usr/bin/sysetmd5e150cad", F_OK) == 0)
    {
		flag = 1;
        printf("[+] 发现Systmd病毒-sysetmd5e150cad\n");
		remove("/usr/bin/sysetmd5e150cad");
		printf("[-] 已清除威胁\n");
    }
	if(access("/bin/sysetmd5e150cad",F_OK)==0)
	{
		flag = 1;
		printf("[+] 发现Systmd病毒-sysetmd5e150cad\n");
		remove("/bin/sysetmd5e150cad");
		printf("[-] 已清除威胁\n");
	}
    if(flag)
    {
        printf("[*] 文件未发现Systmd病毒\n");
    }
	
}

int CheckTaskCrntab()
{
	FILE *fstream = NULL;
    char buffer[1024];
    int found = -1;
 
    memset(buffer, 0, sizeof(buffer));  

    sprintf(buffer, "cat /etc/crontab");
    if (NULL == (fstream = popen(buffer,"r")))      
    {     
        return -1;      
    }   
 
    while (NULL != fgets(buffer, sizeof(buffer), fstream)) 
    {  
        if (strstr(buffer, "*/3 * * * * root /etc/cron.hourly/cron.sh") != NULL)
        {
			printf("[+] 发现威胁cron计划任务\n");
			// /etc/cron.hourly/cron.sh
			if (access("/etc/cron.hourly/cron.sh", F_OK) == 0)
			{
				flag = 1;
				printf("[-] 清除cron.hourly/cron.sh.....\n");
				remove("/etc/cron.hourly/cron.sh");
				printf("[+] 已清除威胁\n");
			}
        }
    }
 
    pclose(fstream);
	
}

int CheckLnk()
{    
	char buffer[1024];
	char lnkpath[1024];
    // int found = -1;
    memset(buffer, 0, sizeof(buffer)); 
	memset(buffer, 0, sizeof(lnkpath));
	for(int i = 0 ; i <=5; ++i)
	{
		sprintf(buffer, "ls /etc/rc%d.d/ | grep S90", i);
		if (NULL == (fstream = popen(buffer,"r")))      
		{
			continue;
		}
		else
		{
			if(NULL != fgets(buffer, sizeof(buffer), fstream))
			{
				printf("[+] 发现威胁%s\n", buffer);
				sprintf(lnkpath, "/etc/rc%d.d/%s" , i, buffer);
				remove(lnkpath);
				printf("[-] 威胁已清除");
			}
		}
	}

	for(int i = 0 ; i <=5; ++i)
	{
		sprintf(buffer, "ls /etc/rc.d/rc%d.d/ | grep S90", i);
		if (NULL == (fstream = popen(buffer,"r")))      
		{
			continue;
		}
		else
		{
			if(NULL != fgets(buffer, sizeof(buffer), fstream))
			{
				printf("[+] 发现威胁%s\n", buffer);
				sprintf(lnkpath, "/etc/rc%d.d/%s" , i, buffer);
				remove(lnkpath);
				printf("[-] 威胁已清除");
			}
		}
	}
}


int main(void)
{
	int selectNumber = 0;
	printf("[+] Systmd病毒查杀开始，请稍等......\n");		
	
	CheckVirusFile();
	
	CheckTaskCrntab();
	
	CheckLnk();
	
	printf("[+] Systmd查杀结束！\n");
}