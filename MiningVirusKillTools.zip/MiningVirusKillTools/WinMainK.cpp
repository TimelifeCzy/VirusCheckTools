#include "WinMainK.h"
#include "XwinControl.h"

WinMainK g_WinApp;

WinMainK::WinMainK()
{

}

WinMainK::~WinMainK()
{

}

BOOL WinMainK::InitInstance()
{
	XwinControl obj;
	m_pMainWnd = &obj;
	obj.DoModal();
	return TRUE;
}