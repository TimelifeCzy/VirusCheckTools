#pragma once
#include <afxwin.h>
#include <Windows.h>


/*
	Class Name: ProgramEntryPoint
	The Functionality: ������ڵ�
*/

class WinMainK : public CWinApp
{
public:
	WinMainK();
	virtual ~WinMainK() override;
private:
	virtual BOOL InitInstance() override;

private:
	/*
		��װ����.sys
	*/
	BOOL InitDevice();
	BOOL InstallDevice();
	BOOL UnInstallDevice();
};