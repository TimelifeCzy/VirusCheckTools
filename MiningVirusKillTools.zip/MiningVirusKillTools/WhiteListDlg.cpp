﻿// WhiteListDlg.cpp: 实现文件
//

#include "stdafx.h"
#include "WhiteListDlg.h"
#include "afxdialogex.h"
#include "resource.h"

// WhiteListDlg 对话框

IMPLEMENT_DYNAMIC(WhiteListDlg, CDialogEx)

vector<CString> WhiteListDlg::g_WhiteList;

WhiteListDlg::WhiteListDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG2, pParent)
{

}

WhiteListDlg::~WhiteListDlg()
{
}

void WhiteListDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_WhiteListView);
	DDX_Control(pDX, IDC_EDIT1, m_EditText);
}


BEGIN_MESSAGE_MAP(WhiteListDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &WhiteListDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &WhiteListDlg::OnBnClickedButton2)
END_MESSAGE_MAP()


// WhiteListDlg 消息处理程序


BOOL WhiteListDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	CRect rc;
	this->GetClientRect(rc);
	int nWidth = rc.Width();
	// 2.获取/设置风格
	DWORD dwOldStyle;
	dwOldStyle = m_WhiteListView.GetExtendedStyle();
	m_WhiteListView.SetExtendedStyle(dwOldStyle | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_WhiteListView.InsertColumn(0, L"白名单名称", LVCFMT_CENTER, nWidth / 1);

	// 不支持批量添加与数据校验，如果程序关闭则虚重新添加，后期优化，写到本地然或启动时读取
	m_EditText.SetWindowTextW(L"");

	SetEditWhiteListData();

	return TRUE;
}

void WhiteListDlg::SetEditWhiteListData()
{
	CString hah;
	m_WhiteListView.DeleteAllItems();

	if (g_WhiteList.empty())
		return;
	
	m_WhiteListView.InsertItem(0, g_WhiteList[0].GetBuffer());
	for (size_t i = 1; i < g_WhiteList.size(); ++i)
	{
		m_WhiteListView.InsertItem(i, g_WhiteList[i].GetBuffer());
	}

}

// 添加按钮
void WhiteListDlg::OnBnClickedButton1()
{
	CString buf;
	// m_EditText.GetDlgItemTextW(IDC_EDIT1, buf);
	m_EditText.GetWindowTextW(buf);
	g_WhiteList.push_back(buf);
	SetEditWhiteListData();
	// TODO: 在此添加控件通知处理程序代码
}

// 删除按钮
void WhiteListDlg::OnBnClickedButton2()
{
	/*
		选中某一行，然后删除
	*/
	CString str;
	int index = m_WhiteListView.GetSelectionMark();
	str = m_WhiteListView.GetItemText(index, 0);
	int k = m_WhiteListView.GetSelectionMark();
	m_WhiteListView.SetItemState(k, 0, LVIS_SELECTED | LVIS_FOCUSED);

	vector<CString>::iterator it;

	for (it = g_WhiteList.begin(); it != g_WhiteList.end();)
	{
		if (!StrCmp(str, *it))
			it = g_WhiteList.erase(it);
		else
			++it;
	}

	// 更新列表
	SetEditWhiteListData();
}
