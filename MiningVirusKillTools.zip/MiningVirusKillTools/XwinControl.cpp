﻿// XwinControl.cpp: 实现文件

//
#pragma once
#include "stdafx.h"
#include "XwinControl.h"
#include "afxdialogex.h"
#include "resource.h"
#include <psapi.h>
#include <tlhelp32.h>
#include <string>
#include <regex>
#include <list>
#include <Windows.h>
#include "WhiteListDlg.h"
#include "BlackListDlg.h"
#include <pdh.h>
#pragma comment ( lib ,"Pdh.lib")

#define MAXPATH 80
#define BUFSIZE 512
#define MY_PROCESS_ERROR(Condition) do{ if (!(Condition))  goto Exit0; } while (false)


/*
	1. 黑名单 VirusName vector
	2. 白名单，可以是路径，文件名、注册表等
	3. 检测进程保存 CheckProVirus List
*/
vector<VIRUSDATA> XwinControl::g_BlackList;
vector<CString>  g_WhiteList;
list<CHECKVIRUS> g_CheckProVirus;

// XwinControl 对话框

IMPLEMENT_DYNAMIC(XwinControl, CDialogEx)

// 全局cpu占用率
double g_nProcessCpuPercent = 0;

// CPU监控线程
DWORD WINAPI ThreadProc(LPVOID lparameter)
{
	XwinControl *pDlg = (XwinControl*)lparameter;
	
	pDlg->GetCpuInfo();

	return 0;
}

// CPU图形显示线程
DWORD WINAPI ThreadProcCpu(LPVOID lparameter)
{
	XwinControl *pDlg = (XwinControl*)lparameter;
	pDlg->m_CpuGroup.SetPos((UINT)pDlg->GetCpuInfo());
	return 0;
}

// 挖矿进程扫描线程
DWORD WINAPI ThreadCheckProcCpu(LPVOID lparameter)
{
	XwinControl *pDlg = (XwinControl*)lparameter;
	pDlg->FindVirusProcess();
	return 0;
}

// 实时监视线程
DWORD WINAPI ThreadProcMonitot(LPVOID lparameter)
{
	double cpus = 0;
	while (true)
	{
		Sleep(1000);
		XwinControl *pDlg = (XwinControl*)lparameter;
		cpus = pDlg->GetCpuInfo();
		if (cpus > 60)
		{
			AfxMessageBox(L"系统Cpu占用率已超过80%，请一键检测");
			// 一分钟总后在次提醒
			Sleep(60000);
		}

	}
}

XwinControl::XwinControl(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG1, pParent)
{

}

XwinControl::~XwinControl()
{
}

void XwinControl::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_List1);
	//  DDX_Control(pDX, IDC_BUTTON1, m_Logs);
	DDX_Control(pDX, IDC_STATIC1, m_Pictrue);
	DDX_Control(pDX, IDC_EDIT2, m_cpuinfo);
	DDX_Control(pDX, IDC_STATIC_MonText, m_MonitorFlagText);
	//  DDX_Control(pDX, IDC_BUTTON1, m_ScanProces);
	DDX_Control(pDX, IDC_STATIC_CHECKPROCESS, m_ScanProcess);
}


BEGIN_MESSAGE_MAP(XwinControl, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &XwinControl::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &XwinControl::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &XwinControl::OnBnClickedButton3)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON4, &XwinControl::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON5, &XwinControl::OnBnClickedButton5)
END_MESSAGE_MAP()


// XwinControl 消息处理程序
BOOL XwinControl::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  在此添加额外的初始化
		// 1.获取宽度
	CRect rc;
	this->GetClientRect(rc);
	int nWidth = rc.Width();
	// 2.获取/设置风格
	DWORD dwOldStyle;
	dwOldStyle = m_List1.GetExtendedStyle();
	m_List1.SetExtendedStyle(dwOldStyle | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);

	m_List1.InsertColumn(0, L"事件ID", 0, nWidth / 8);
	m_List1.InsertColumn(1, L"进程/文件", 0, nWidth / 8);
	m_List1.InsertColumn(2, L"CPU占用率", 0, nWidth / 8);
	m_List1.InsertColumn(3, L"定性", 0, nWidth / 8);
	m_List1.InsertColumn(4, L"模块路径", 0, nWidth / 8);

	// 初始化黑名单(已知的杀毒)
	VIRUSDATA initdata = { 0, };
	memset(&initdata, 0, sizeof(VIRUSDATA));
	CString path;
	StrCpy(initdata.s_name, L"xmrig");
	StrCpy(initdata.Path[0], L"C:\\Windows\\reg\\REBE1l.exe");
	StrCpy(initdata.Path[1], L"C:\\Windows\\reg\\registery.reg");
	g_BlackList.push_back(initdata);
	memset(&initdata, 0, sizeof(VIRUSDATA));
	StrCpy(initdata.s_name, L"the god");
	g_BlackList.push_back(initdata);

	// 设置小图标
	SetIcon(LoadIcon(AfxGetApp()->m_hInstance, MAKEINTRESOURCE(IDI_ICON1)), FALSE);

	// 设置bitmap图片
	CBitmap* p = new CBitmap();
	p->LoadBitmapW(IDB_BITMAP1);
	m_Pictrue.SetBitmap((HBITMAP)p->m_hObject);

	// 提权
	GetSystempermissions();
	
	//Cpu占用监视 
	GetCpuInfo();
	SetTimer(1, 1000, NULL);

	CRect rect;

	// 获取静态控件的举行
	GetDlgItem(IDC_STATIC_CPU)->GetWindowRect(rect);

	// 将该矩形转化为客户窗口
	ScreenToClient(rect);

	// 调用Create函数，并将上面的矩形传入
	m_CpuGroup.Create(WS_VISIBLE | WS_CHILD

		| WS_TABSTOP, rect, this, IDC_STATIC_CPU);

	return TRUE;
}

// 时间转换
double FILETIMEDouble(const _FILETIME & filetime)
{
	return double(filetime.dwHighDateTime * 4.294967296e9) + double(filetime.dwLowDateTime);
}

// 获取CPU占用
double XwinControl::GetCpuInfo()
{
	// 获取空闲时间 内核 用户
	_FILETIME idleTime, kernelTime, userTime;
	GetSystemTimes(&idleTime, &kernelTime, &userTime);
	// Creates or opens a named or unnamed event object.
	// 创建或打开一个命名的或无名的事件对象。
	// failure 0  | sucess handle
	HANDLE hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	//  等待1000毫秒，内核对象会更精确
	WaitForSingleObject(hEvent, 1000);
	// 获取新的时间
	_FILETIME newidleTime, newkernelTime, newuserTime;
	GetSystemTimes(&newidleTime, &newkernelTime, &newuserTime);

	// 转换时间
	double	doldidleTime = FILETIMEDouble(idleTime);
	double	doldkernelTime = FILETIMEDouble(kernelTime);
	double	dolduserTime = FILETIMEDouble(userTime);
	double	dnewidleTime = FILETIMEDouble(newidleTime);
	double	dnewkernelTime = FILETIMEDouble(newkernelTime);
	double	dnewuserTime = FILETIMEDouble(newuserTime);
	double	Times = dnewidleTime - doldidleTime;
	double	Kerneltime = dnewkernelTime - doldkernelTime;
	double	usertime = dnewuserTime - dolduserTime;

	// 计算使用率
	// int Cpurate = ((kernel - idle + user) * 100) / (kernel + user);
	double Cpurate = (100.0 - Times / (Kerneltime + usertime) * 100.0);

	m_Cpusyl.Format(L"%0.2lf", Cpurate);
	m_Cpusyl += "%";
	m_cpuinfo.SetWindowTextW(m_Cpusyl);

	return Cpurate;
}

/*
	方案：
		采用pdb库
*/
double GetProcessCpu(CString ProcessName)
{
	auto indexs = ProcessName.ReverseFind('.');
	// auto indexs  = StrStr(ProcessName.GetBuffer(), L".exe");
	ProcessName = ProcessName.Left(indexs);

	HQUERY query;
	PDH_STATUS status = PdhOpenQuery(NULL, NULL, &query);

	if (status != ERROR_SUCCESS)
		return -1;

	PDH_HCOUNTER counter;
	CString QuerPath = "\\Process(";
	QuerPath += ProcessName;
	QuerPath += ")\\% Processor Time";
	status = PdhAddCounter(query, QuerPath.GetBuffer(), NULL, &counter);

	if (status != ERROR_SUCCESS)
		return -1;

	PdhCollectQueryData(query);

	Sleep(500);

	PdhCollectQueryData(query);

	PDH_FMT_COUNTERVALUE pdhValue;
	DWORD dwValue;

	status = PdhGetFormattedCounterValue(counter, PDH_FMT_DOUBLE, &dwValue, &pdhValue);

	if (status != ERROR_SUCCESS)
		return -1;

	PdhCloseQuery(query);

	return pdhValue.doubleValue;
}

// 封装遍历进程及获取cpu内存状态
BOOL XwinControl::FindVirusProcess()
{
	DWORD WhiteListFlag = 0;
	g_orderid = 1;
	g_index = 0;
	// 驱动模块转换文件路径
	CString temp, strcat;

	// 初始化无效的句柄值
	HANDLE hprocess = INVALID_HANDLE_VALUE;
	PROCESSENTRY32W p_32 = { 0 };
	
	// 初始化结构体
	VIRUSDATA virusinfo = { 0, };
	CHECKVIRUS checkvirus;
	
	// 1.创建进程快照
	hprocess = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if (INVALID_HANDLE_VALUE != hprocess)
	{
		p_32.dwSize = sizeof(PROCESSENTRY32W);
		// 计算当前循环次数
		int count = 0;
		// 开始遍历进程
		if (!Process32First(hprocess, &p_32))
		{
			AfxMessageBox(L"Process32First falure!");
			CloseHandle(hprocess);
			return FALSE;
		}
		// 循环遍历进程
		do
		{
			temp = p_32.szExeFile;
			// 全部转换成小写在比较
			temp.MakeLower();
			// 获取进程占用CPU
			g_nProcessCpuPercent = GetProcessCpu(p_32.szExeFile);
			// 设置线程扫描显示
			m_ScanProcess.SetWindowTextW(p_32.szExeFile);
		
			// 1. 首先匹配黑名单 和 cpu占用率70 为可疑挖矿
			for (size_t i = 0; i < g_BlackList.size(); ++i)
			{
				if (_tcsstr(temp, g_BlackList[i].s_name) || (g_nProcessCpuPercent > 70))
				{
					// 2. 白名单过滤，代码回来优化
					for (size_t wls = 0; wls < g_WhiteList.size(); ++wls)
					{
						if (_tcsstr(p_32.szExeFile, g_WhiteList[i].GetBuffer()))
						{
							WhiteListFlag = 1;
							break;
						}
					}
					// 白名单符合，免杀进程
					if (WhiteListFlag)
						continue;

					/*
						符合可以进程条件
					*/
					StrCpy(virusinfo.s_name, temp);
					// 不把自己列入优化，改成GetCurrentPr
					if (p_32.th32ProcessID == GetCurrentProcessId())
						continue;
					// 成功匹配
					_stprintf_s(bufs, MAX_PATH, L"%d", g_orderid);
					m_List1.InsertItem(g_index, bufs);

					// 进程/文件名称
					m_List1.SetItemText(g_index, 1, p_32.szExeFile);

					_stprintf_s(bufs, MAX_PATH, L"%0.2f", g_nProcessCpuPercent);
					g_nProcessCpuPercent = 0;
					m_List1.SetItemText(g_index, 2, bufs);

					// 定性
					m_List1.SetItemText(g_index, 3, L"疑似挖矿进程");

					/*
						获取进程模块路径，需要转换驱动路径到文件路径
					*/
					HANDLE virusHand = OpenProcess(PROCESS_ALL_ACCESS, false, p_32.th32ProcessID);
					GetProcessImageFileName(virusHand, pszFileName, MAX_PATH);
					/*
						下面匹配那个盘符路径
					*/
					TCHAR szTemp[MAX_PATH] = { 0 };
					TCHAR  szName[MAX_PATH];
					TCHAR  szDrive[3] = { 0 };
					BOOL   bFound = FALSE;
					// 通过指针p的移动来顺序访问所有的驱动器目录
					PTCHAR p = szTemp;
					do
					{
						//获取电脑上的所有驱动器，如"C:\"  "D:\"等，连续放置的
						if (0 == GetLogicalDriveStrings(BUFSIZE - 1, szTemp))
						{
							printf("GetLogicalDriveStrings error: %d", GetLastError());
							return FALSE;
						}

						CopyMemory(szDrive, p, 2 * sizeof(TCHAR));
						//通过路径查找设备名，如"C:"
						if (!QueryDosDevice(szDrive, szName, BUFSIZE))
						{
							printf("QueryDosDrive error: %d", GetLastError());
							return FALSE;
						}
						UINT uNameLen = lstrlen(szName);
						if (uNameLen < MAX_PATH)
						{
							//比较驱动器的设备名文件名与文件设备名是否匹配
							bFound = StrNCmp(pszFileName, szName, uNameLen) == 0;
							if (bFound)
							{
								//如果匹配，说明已找到，构造路径
								TCHAR szTempFile[MAX_PATH];
								wsprintf(szTempFile,
									TEXT("%s%s"),
									szDrive,
									pszFileName + uNameLen);
								lstrcpy(pszFileName, szTempFile);
								break;
							}
						}
						while (*p++);
					} while (!bFound && *p);

					m_List1.SetItemText(g_index, 4, pszFileName);
					
					/*
						全局链表保存病毒信息
					*/
					checkvirus.VirusHandle = virusHand;
					checkvirus.VirusName = p_32.szExeFile;
					checkvirus.VirusPath = pszFileName;
					g_CheckProVirus.push_back(checkvirus);

					/*
						Check or viruskill:
						1：代表检测
						2：代表查杀
					*/
					++g_index;
					++g_orderid;
				}
			}
		} while (Process32Next(hprocess, &p_32));
	}
	else
	{
		AfxMessageBox(L"CreateToolhelp32Snapshot failure!");
		return -1;
	}
	return 0;
}

// 匹配挖矿进程信息(核心)
BOOL XwinControl::GetProcessVirus()
{
	m_List1.DeleteAllItems();
	g_nProcessCpuPercent = 0;

	HANDLE thProcces = CreateThread(NULL, NULL, ThreadCheckProcCpu, (LPVOID)this, NULL, NULL);

	AfxMessageBox(L"正在检测，请稍等一会......");

	return TRUE;
}

// 获取系统权限
void XwinControl::GetSystempermissions()
{
	HANDLE hToken = NULL;
	// 获取伪句柄（该线程）
	HANDLE hProcess = GetCurrentProcess();
	OpenProcessToken(hProcess, TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken);
	TOKEN_PRIVILEGES tp = { 0 };
	LookupPrivilegeValue(0, SE_SHUTDOWN_NAME, &tp.Privileges[0].Luid);
	// 特权计数
	tp.PrivilegeCount = 1;
	tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
	AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(tp), NULL, NULL);
}

// 一键查杀
void XwinControl::OnBnClickedButton2()
{
	CString huozui = ".virus";

	// 1. 枚举进程获取包含XmRig进程，然后找到文件路径，Kill掉进程，删除文件
	if (g_CheckProVirus.size())
	{
		CHECKVIRUS checkvs;

		for (list<CHECKVIRUS>::iterator iter = g_CheckProVirus.begin(); iter != g_CheckProVirus.end(); ++iter)
		{
			checkvs = *iter;
			// 1. 清理进程
			TerminateProcess(checkvs.VirusHandle, NULL);
			CloseHandle(checkvs.VirusHandle);

			huozui = checkvs.VirusPath.GetBuffer() + huozui;

			// 2. 删除病毒文件
			//	DeleteFile();
			_wrename(checkvs.VirusPath.GetBuffer(), huozui);
		}

		AfxMessageBox(L"隔离成功，请重新一键检测");

		// 清理全局链表保存的已查杀病毒
		g_CheckProVirus.clear();
	}
	else
	{
		AfxMessageBox(L"请一键检测完毕后在查杀或您电脑安全!");
	}
}

// 一键检测
void XwinControl::OnBnClickedButton1()
{
	GetProcessVirus();
}

// 监控
void XwinControl::OnBnClickedButton3()
{
	// 创建监控简称
	if (!g_MonitorCpuflag)
	{
		hMonitorCpu = CreateThread(NULL, NULL, ThreadProcMonitot, (LPVOID)this, NULL, NULL);
		g_MonitorCpuflag = TRUE;
		m_MonitorFlagText.SetWindowTextW(L"已开启");

	}
	else
	{
		TerminateThread(hMonitorCpu, NULL);
		hMonitorCpu = NULL;
		g_MonitorCpuflag = FALSE;
		m_MonitorFlagText.SetWindowTextW(L"未开启");
	}
}

// 定时器
void XwinControl::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	HANDLE thProcces = CreateThread(NULL, NULL, ThreadProc, (LPVOID)this, NULL, NULL);
	HANDLE thCpuProc = CreateThread(NULL, NULL, ThreadProcCpu, (LPVOID)this, NULL, NULL);
	CDialogEx::OnTimer(nIDEvent);
}

// 白名单功能
void XwinControl::OnBnClickedButton4()
{
	/*
	方案：
		1. 需要把添加到白名单的进程名，从黑名单删除
		2. 判断的时候过滤，查杀黑名单同时，可以过滤掉白名单中的
	*/
	g_WhiteList.clear();

	WhiteListDlg whitelistobj;
	whitelistobj.DoModal();

	for (size_t i = 0; i < whitelistobj.g_WhiteList.size(); ++i)
	{
		g_WhiteList.push_back(whitelistobj.g_WhiteList[i].GetBuffer());
	}
}

// 黑名单
void XwinControl::OnBnClickedButton5()
{
	/*
	方案：
		全局black不更换，将blacklist.Cstring为全局
	*/

	// 初始化黑名单
	BlackListDlg blacklistobj;
	blacklistobj.DoModal();
}
