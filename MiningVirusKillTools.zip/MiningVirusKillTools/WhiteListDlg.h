﻿#pragma once
#include <vector>

using namespace std;
// WhiteListDlg 对话框

class WhiteListDlg : public CDialogEx
{
	DECLARE_DYNAMIC(WhiteListDlg)

public:
	WhiteListDlg(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~WhiteListDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG2 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	CListCtrl m_WhiteListView;
	CEdit m_EditText;
	afx_msg void OnBnClickedButton1();

public:
	static vector<CString> g_WhiteList;
	void SetEditWhiteListData();
	afx_msg void OnBnClickedButton2();
};
