﻿// BlackListDlg.cpp: 实现文件
//

#include "stdafx.h"
#include "BlackListDlg.h"
#include "afxdialogex.h"
#include "XwinControl.h"

//typedef struct _VIRUSDATAA
//{
//	TCHAR s_name[30];	// 病毒名称
//	TCHAR Path[10][0x1024];	// 病毒像关文件路径，暂时不细划分
//}VIRUSDATAA, *PVIRUSDATAA;

VIRUSDATA temdata = { 0, };

vector<CString> BlackListDlg::m_blacklistDlg;

// BlackListDlg 对话框

IMPLEMENT_DYNAMIC(BlackListDlg, CDialogEx)

BlackListDlg::BlackListDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG3, pParent)
	, m_EditText(_T(""))
{

}

BlackListDlg::~BlackListDlg()
{
}

void BlackListDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_blacklistview);
	DDX_Text(pDX, IDC_EDIT1, m_EditText);
}


BEGIN_MESSAGE_MAP(BlackListDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &BlackListDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &BlackListDlg::OnBnClickedButton2)
END_MESSAGE_MAP()

// BlackListDlg 消息处理程序
void BlackListDlg::SetListView()
{
	m_blacklistview.DeleteAllItems();
	m_blacklistview.InsertItem(0, L" ");
	for (size_t i = 0; i < XwinControl::g_BlackList.size(); ++i)
	{
		m_blacklistview.InsertItem(i, XwinControl::g_BlackList[i].s_name);
	}
}


// 添加
void BlackListDlg::OnBnClickedButton1()
{
	UpdateData(TRUE);
	// 转换成小写
	StrCpy(temdata.s_name, m_EditText.MakeLower());
	XwinControl::g_BlackList.push_back(temdata);
	SetListView();
}

// 删除
void BlackListDlg::OnBnClickedButton2()
{
	CString str;
	int index = m_blacklistview.GetSelectionMark();
	str = m_blacklistview.GetItemText(index, 0);
	int k = m_blacklistview.GetSelectionMark();
	m_blacklistview.SetItemState(k, 0, LVIS_SELECTED | LVIS_FOCUSED);

	vector<VIRUSDATA>::iterator it;
	VIRUSDATA tem = { 0, };

	for (it = XwinControl::g_BlackList.begin(); it != XwinControl::g_BlackList.end();)
	{
		tem = (VIRUSDATA)(*it);
		if (!StrCmp(str, tem.s_name))
		{
			XwinControl::g_BlackList.erase(it);
			break;
		}
		else
			++it;
	}

	SetListView();
}

BOOL BlackListDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	CRect rc;
	this->GetClientRect(rc);
	int nWidth = rc.Width();
	// 2.获取/设置风格
	DWORD dwOldStyle;
	dwOldStyle = m_blacklistview.GetExtendedStyle();
	m_blacklistview.SetExtendedStyle(dwOldStyle | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_blacklistview.InsertColumn(0, L"黑名单名称", LVCFMT_CENTER, nWidth / 1);

	SetListView();

	return TRUE; 
}
