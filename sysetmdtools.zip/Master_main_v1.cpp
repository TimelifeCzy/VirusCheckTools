#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <dirent.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
#include <assert.h>

#include <fstream>
#include <openssl/md5.h>
#include <string>
#include <cstdio>

using namespace std;
 
/***** Global Variables *****/
char dir[100] = "/";
int const MAX_STR_LEN = 200;

std::string gMd5 = "577e026287024efdf718a3d4d8fc46c0";

int CheckTaskCrntab()
{
    FILE *fstream = NULL;
    char buffer[1024];
    int found = -1;
 
    memset(buffer, 0, sizeof(buffer));  

    sprintf(buffer, "cat /etc/crontab");
    if (NULL == (fstream = popen(buffer,"r")))      
    {     
        return -1;      
    }   
 
    while (NULL != fgets(buffer, sizeof(buffer), fstream)) 
    {  
        if (strstr(buffer, "*/3 * * * * root /etc/cron.hourly/cron.sh") != NULL)
        {
		printf("[+] 发现威胁cron计划任务\n");
		// /etc/cron.hourly/cron.sh
		if (access("/etc/cron.hourly/cron.sh", F_OK) == 0)
		{
			printf("[-] 清除cron.hourly/cron.sh.....\n");
			remove("/etc/cron.hourly/cron.sh");
			printf("[+] 已清除威胁\n");
		}
        }
    }
    pclose(fstream);
    fstream = NULL;
    return 0;
}

int CheckLnk()
{    
	FILE *fstream = NULL;
	char buffer[1024];
	char lnkpath[1024];
    memset(buffer, 0, sizeof(buffer)); 
	memset(buffer, 0, sizeof(lnkpath));
	for(int i = 0 ; i <=5; ++i)
	{
		sprintf(buffer, "ls /etc/rc%d.d/ | grep S90", i);
		if (NULL == (fstream = popen(buffer,"r")))      
		{
			continue;
		}
		else
		{
			if(NULL != fgets(buffer, sizeof(buffer), fstream))
			{
				printf("[+] 发现威胁%s\n", buffer);
				sprintf(lnkpath, "/etc/rc%d.d/%s" , i, buffer);
				remove(lnkpath);
				printf("[-] 威胁已清除");
			}
		}
	}
	
	pclose(fstream);
	fstream = NULL;
	
	for(int i = 0 ; i <=5; ++i)
	{
		sprintf(buffer, "ls /etc/rc.d/rc%d.d/ | grep S90", i);
		if (NULL == (fstream = popen(buffer,"r")))      
		{
			continue;
		}
		else
		{
			if(NULL != fgets(buffer, sizeof(buffer), fstream))
			{
				printf("[+] 发现威胁%s\n", buffer);
				sprintf(lnkpath, "/etc/rc%d.d/%s" , i, buffer);
				remove(lnkpath);
				printf("[-] 威胁已清除\n");
			}
		}
	}
	pclose(fstream);
	fstream = NULL;
	return 0;
}

void printLoop() 
{
	static int iCount = 0;
	const char *loop = "-\\|/";
	iCount++;
	printf("\x08%c", loop[iCount/3%4]);
}

int get_file_md5(const std::string &file_name, std::string &md5_value)
{
    md5_value.clear();

    std::ifstream file(file_name.c_str(), std::ifstream::binary);
    if (!file)
    {
        return -1;
    }

    MD5_CTX md5Context;
    MD5_Init(&md5Context);

    char buf[1024 * 16];
    while (file.good()) {
        file.read(buf, sizeof(buf));
        MD5_Update(&md5Context, buf, file.gcount());
    }

    unsigned char result[MD5_DIGEST_LENGTH];
    MD5_Final(result, &md5Context);

    char hex[35];
    memset(hex, 0, sizeof(hex));
    for (int i = 0; i < MD5_DIGEST_LENGTH; ++i)
    {
        sprintf(hex + i * 2, "%02x", result[i]);
    }
    hex[32] = '\0';
    md5_value = string(hex);

    return 0;
}

bool removeFile(const char * path) 
{
	char buffer[1024];
	memset(buffer,0,1024);
	sprintf(buffer,"chattr -i %s", path);
	popen(buffer,"r");
	printf("[-] chattr -i 解锁\r\n");
	return remove(path);
}

void calcMd5 (const char * path) 
{
	std::string md5Value;
	std::string filePath(path);
	
	printLoop();
	
	if (get_file_md5(filePath, md5Value)) {
		return;
	}
	
	if (!gMd5.compare(md5Value)) {
		printf("[*] 发现威胁%s\n", path);
		if (!removeFile(path)) {
			printf("[+] 已清除威胁\r\n");
		} else {
			printf("[-] 清除威胁失败，请手动查看\r\n");
		}
	}
}

/* Show all files under dir_name , do not show directories ! */
void showAllFiles( const char * dir_name )
{
	// check the parameter !
	if( NULL == dir_name )
	{
		cout<<" dir_name is null ! "<<endl;
		return;
	}
 
	// check if dir_name is a valid dir

	
	struct dirent * filename;    // return value for readdir()
 	DIR * dir;                   // return value for opendir()
	dir = opendir( dir_name );
	if( NULL == dir )
	{
		return;
	}
	
	/* read all the files in the dir ~ */
	while( ( filename = readdir(dir) ) != NULL )
	{
		// get rid of "." and ".."
		if( strcmp( filename->d_name , "." ) == 0 || 
			strcmp( filename->d_name , "..") == 0    )
			continue;
			
		struct stat s;
		std::string a = dir_name ;
		a += "/";
		a += filename->d_name;
		lstat( a.c_str() , &s );
		if(S_ISDIR( s.st_mode ) )
		{
			if (strcmp(filename->d_name, "sys") == 0) {
				continue;
			}
			if (strcmp(filename->d_name, "dev") == 0) {
				continue;
			}
			showAllFiles(a.c_str());
		} else {
			//cout<< a <<endl;
			calcMd5(a.c_str());
		}
	}
} 

int main()
{
	// 测试
	printf("[+] Systmd病毒查杀开始，请稍等......\n");	

	showAllFiles("/");
	
	CheckTaskCrntab();
	
	CheckLnk();
	
	printf("[+] Systmd查杀结束！\n");
	
	return 0;
}
