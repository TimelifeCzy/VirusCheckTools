﻿#pragma once
#include "resource.h"
#include <vector>
// BlackListDlg 对话框
using namespace std;

class BlackListDlg : public CDialogEx
{
	DECLARE_DYNAMIC(BlackListDlg)

public:
	BlackListDlg(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~BlackListDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG3 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_blacklistview;
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
	CString m_EditText;
	virtual BOOL OnInitDialog();

public:
	static vector<CString> m_blacklistDlg;
	void SetListView();
};
